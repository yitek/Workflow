package WF.graphs;

import lombok.*;
import java.util.*;

@Data
public class Node {
    NodeTypes type;
    String name;
    Map<String,String> variables;
    List<String> inParameters;
    List<String> outParameters;
    //List<Node> childNodes;
    List<Association> childAssociations;
}
