package WF.graphs;

import lombok.*;

@Data
public class Association {
    String from;
    String to;
    String name;
}
