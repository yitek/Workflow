package WF.graphs;

public enum NodeTypes {
    Normal
}
